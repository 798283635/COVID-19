# Run the site

Ensure you have the latest version of yarn. On Mac you can install yarn via `brew install yarn` (see https://yarnpkg.com/en/docs/install#debian-stable for other systems). To run the site:

- `cd website`
- `yarn add packages.json`
- `yarn run start`

For more info, consult [Docusaurus' doc](https://docusaurus.io/docs/en/installation.html)
