# Datasets
Download the following three datasets into their corresponding folders.

## Penn TreeBank 
Penn Treebank is available at https://github.com/wojzaremba/lstm/tree/master/data

## WikiText-2
WikiText-2 is available at https://s3.amazonaws.com/research.metamind.io/wikitext/wikitext-2-v1.zip

## Reddit comments 

Reddit Comments dataset is available at https://www.kaggle.com/reddit/reddit-comments-may-2015/home

