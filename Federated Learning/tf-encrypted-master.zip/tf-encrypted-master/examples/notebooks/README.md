# Using TF Encrypted in Jupyter Notebooks

Note that GitHub may not render the notebooks correctly, in which case consider using [nbviewer.jupyter.org](https://nbviewer.jupyter.org/).
