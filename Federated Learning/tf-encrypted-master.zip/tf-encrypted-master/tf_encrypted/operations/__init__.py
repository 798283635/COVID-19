"""Python client API for custom Ops."""
from . import secure_random

__all__ = [
    "secure_random"
]
