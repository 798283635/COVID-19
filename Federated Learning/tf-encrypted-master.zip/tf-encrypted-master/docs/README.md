# Documentation

This directory contains various resources for using TF Encrypted, including [installation](./INSTALL.md) and [running](./RUNNING.md).

See also the [examples](/examples/) and the [API documentation](https://tf-encrypted.readthedocs.io/en/latest/index.html).
